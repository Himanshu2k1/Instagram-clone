// api for login page & new registration
import axios from "axios";

export default axios.create({
    baseURL:'http://localhost:4000'
});